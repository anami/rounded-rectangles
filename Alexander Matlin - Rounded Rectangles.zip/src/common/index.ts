export {
    IRectangle,
    IRectangleExtended,
    Rectangle
} from './rectangle.model';

export {
    IRectangleActionPointer,
    RectangleActionPointer
} from './rectangleActionPointer.model';